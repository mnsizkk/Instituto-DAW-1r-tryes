﻿//PROGRAMA #2 Carmels
internal class Program
{
/// Un professor ha decidit repartir un total de carmels entre els nens de la seva classe.
/// El professor vol repartir el màxim de carmels per nen, però vol que tots els nens tingui el mateix # de carmels
/// El professor es quedarà els caramels que sobrin.
/// El programa ha de demanar el # de carmels i el # de nens i informar de 
/// a) quants carmels toquen per nen.
/// b) quants carmels es quedarà el professor.
    private static void Main(string[] args)
    {
        int nCarmels, nNens;
        int carmelsPerNen, sobren;
        Console.Clear();
        Console.WriteLine("Quants nens?");
        nNens=Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Quants carmels? ");
        nCarmels = Convert.ToInt32(Console.ReadLine());
        carmelsPerNen = nCarmels / nNens;
        sobren = nCarmels % nNens;
        Console.WriteLine($"TOTAL NENS : {nNens}\t\t TOTAL CARMELS : {nCarmels}");
        Console.WriteLine($"TOQUEN A {carmelsPerNen} CARMELS PER A CADA NEN");
        Console.WriteLine($"EL PROFESSOR ES QUEDA {sobren} CARMELS");
    }   
}