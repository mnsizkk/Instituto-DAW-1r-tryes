﻿//PROGRAMA #1: HelloWorld
internal class Program
{
/// Escriu un programa que et demani el teu nom i et saludi dient HOLA + El teu nom
/// <param name="args"></param>
    private static void Main(string[] args)
    {
        string elTeuNom;
        Console.Clear();
        Console.Write("COM ET DIUS? ");
        elTeuNom = Console.ReadLine();
        Console.Clear();
        Console.WriteLine($"HOLA {elTeuNom}");
    }
}