﻿//PROGRAMA # 3: Volum Esfera
internal class Program
{ 
/// Programa que et demana el radi d'una esfera en metres i et calcula el seu volum (4/3*PI*r*r*r)
/// Compte que el programa té una errada.
/// <param name="args"></param>>
    private static void Main(string[] args)
    {
        const double PI = 3.1416;
        double radi, volum;
        Console.Write("RADI DE LA ESFERA EN METRES ? ");
        radi=Convert.ToDouble(Console.ReadLine());
        volum= 4 / 3 * PI; Math.Pow(radi, 3);
        Console.WriteLine($"ESFERA DE RADI {radi} TÉ UN VOLUM {volum} m3");
    }
}
