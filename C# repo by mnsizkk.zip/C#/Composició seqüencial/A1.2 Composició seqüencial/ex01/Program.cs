﻿//A1.2, Exercici 2 by Josep Ortiz
//En aquest programa el que farem és demanar la nostra edat i que ens digui quants anys farem l'any vinent.

using System; //Això segons la informació que he trobat importa funcionalitats bàsiques com la entrada i sortida a la consola.

class Program //Amb això definim que el programa comença aquí.
{
    static void Main(string[] args) //Això ens indica que el programa comença aquí.
    {
        int edat, edatfutura; //"int" ens indica nombres enters.
        string entrada; //"string" és una cadena de text.

        Console.WriteLine("Quants anys tens? "); 
        entrada = Console.ReadLine();
        edat = Convert.ToInt32(entrada);
        edatfutura = edat + 1;
        Console.WriteLine($"El proxim any faras {edatfutura} anys.");
    }
}
